# Linear-Algebra-with-python

Week 1. Vectors

Week 2. Linear combination and spans, Linear dependence and independence

Week 3. Subspaces and the basis for a subspace, vector dot and cross products

Week 4. Matrices for solving systems by elimination, null space and column space

Week 5. Functions and linear transformation, linear transformation examples

Week 6. Transformations and matrix multiplication, inverse functions and transformation examples

Week 7. Finding inverses and determinants, more determinant depth

Week 8. Transpose of a matrix

Week 9. Orthogonal complements, Orthogonal projections

Week 10. Change of basis, Orthonormal bases and the Gram-Schmidt process

Week 11. Eigen-everything

Week 12. linear algebra in DL/ML
